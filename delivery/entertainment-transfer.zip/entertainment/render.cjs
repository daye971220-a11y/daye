const fs = require('node:fs');
const path = require('node:path');
const dir = __dirname;
const data = JSON.parse(fs.readFileSync(path.join(dir, 'drafts.json'), 'utf8'));
const photos = fs.existsSync(path.join(dir,'photos.json')) ? JSON.parse(fs.readFileSync(path.join(dir,'photos.json'),'utf8')) : [];
const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const bodyStyle = 'font-family:나눔바른고딕,NanumBarunGothic,Arial,sans-serif;font-size:16px;color:#000;text-align:center;line-height:1.9;';
function para(s,d) {
  let out=esc(s);
  d.emphasis.forEach((e,i)=>{out=out.split(esc(e)).join(`<strong style="${i%3===0?'color:#e3548e;':i%3===1?'background-color:#fff49a;':'background-color:#d9f2ae;'}">${esc(e)}</strong>`)});
  return `<p style="${bodyStyle}margin:26px 0;">${out.replace(/\n/g,'<br>')}</p>`;
}
function photo(p){return `<figure style="margin:32px 0;text-align:center;"><img src="${esc(p.file)}" alt="${esc(p.caption)}" style="max-width:100%;height:auto;"><figcaption style="font-size:12px;color:#666;line-height:1.6;">${esc(p.caption)}<br>${esc(p.author)} · <a href="${esc(p.source)}">사진 출처</a> · <a href="${esc(p.licenseUrl)}">${esc(p.license)}</a> · 원본 파일 사용</figcaption></figure>`;}
let text='', guide='작성 기준: 2026-10-06 확인 자료 / 대상 블로그 dangke- / 네이버 입력·임시저장·발행 전\r\n\r\n';
const index=[];
const html=data.drafts.map(d=>{
  const ps=photos.filter(p=>p.drafts.includes(d.id)&&p.role==='body');
  const thumbnail=photos.find(p=>p.drafts.includes(d.id)&&p.role==='thumbnail');
  const raw=[...d.intro,...d.sections.flatMap(s=>[s.heading,...s.paragraphs])].join('\n\n');
  const count=raw.replace(/\s/g,'').length;
  index.push({id:d.id,title:d.title,type:d.type,charactersWithoutWhitespace:count,photos:ps.length,sections:d.sections.length});
  text+=`[${d.id}] ${d.title}\r\n\r\n${raw.replace(/\n/g,'\r\n')}\r\n\r\n출처\r\n${d.sources.map(s=>`${s.name}: ${s.url}`).join('\r\n')}\r\n\r\n────────────────────────\r\n\r\n`;
  guide+=`[${d.id}] ${d.title}\r\n형식: ${d.type} / 본문 공백 제외 ${count}자\r\n썸네일 2차 멘트: ${d.hook}\r\n스티커: ${d.sticker}\r\n${d.sections.map((s,i)=>`${s.heading}: ${ps[i] ? ps[i].file+' ('+ps[i].caption+')' : '사진 미확보 — 해당 장면의 재사용 가능한 원본 확인 필요'}`).join('\r\n')}\r\n썸네일 배경: ${thumbnail?thumbnail.file+' / '+thumbnail.caption+' / '+thumbnail.author+' / '+thumbnail.license+' / '+thumbnail.source:'별도 사진 미확보. 본문 사진과 동일 이미지로 자동 대체하지 않음.'}\r\n핵심 강조: ${d.emphasis.join(' / ')}\r\n\r\n`;
  const body=d.intro.map(s=>para(s,d)).join('')+d.sections.map((s,i)=>`<h2 style="font-family:나눔바른고딕,Arial,sans-serif;font-size:19px;text-align:left;border-left:4px solid #222;padding:8px 14px;margin:48px 0 24px;color:#000;font-weight:500;">${esc(s.heading)}</h2>${ps[i]?photo(ps[i]):''}${s.paragraphs.map(p=>para(p,d)).join('')}`).join('')+`<p style="font-size:12px;color:#666;text-align:left;line-height:1.7;margin-top:40px;">자료 출처<br>${d.sources.map(s=>`<a href="${esc(s.url)}">${esc(s.name)}</a>`).join('<br>')}</p>`;
  return `<article id="draft-${d.id}"><div class="tools"><b>${d.id} · ${esc(d.type)} · 본문 ${count}자</b><button onclick="copyTitle('${d.id}')">제목 복사</button><button onclick="copyBody('${d.id}')">본문 서식 복사</button><span class="feedback" id="feedback-${d.id}" aria-live="polite"></span><p>사진 ${ps.length}/${d.sections.length}장 확보 · 스티커: ${esc(d.sticker)}<br>썸네일 추천 멘트: ${esc(d.hook)}</p></div><h1 id="title-${d.id}">${esc(d.title)}</h1><div id="body-${d.id}" style="${bodyStyle}">${body}</div></article>`;
}).join('');
const document=`<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>연예 원고 13편 · 복사 서식본</title><style>body{background:#f4f4f6;margin:0;font-family:Arial,sans-serif}header,nav{max-width:800px;margin:24px auto;padding:20px;background:white;border-radius:12px}nav a{display:block;line-height:1.6;margin:8px 0;color:#333}article{max-width:720px;margin:28px auto;padding:40px;background:white;border-radius:12px}h1{font-size:27px;line-height:1.5}.tools{background:#f7f1f4;padding:18px;font-size:13px;line-height:1.6}.tools p{margin-bottom:0}button{padding:8px 12px;border:1px solid #ddd;background:white;border-radius:7px;margin:6px;cursor:pointer}.feedback{color:#326a3a}a{color:#555} @media(max-width:760px){article{padding:22px;margin:16px 10px}header,nav{margin:16px 10px}}</style></head><body><header><h1>연예 원고 13편</h1><p>본문 초안·제목·강조 서식 준비. 사진은 확보한 파일만 표시하며, 빠진 사진과 썸네일은 편집 안내에서 확인할 수 있어요.</p><p>복사 버튼은 본문만 복사해요. 네이버 사진 업로드와 인용구·스티커 적용은 로그인 후 편집기에서 마무리해야 해요.</p><a href="drafts.txt" download>텍스트 원고 다운로드</a> · <a href="editor-guide.txt" download>사진·서식·썸네일 편집 안내</a></header><nav>${index.map(d=>`<a href="#draft-${d.id}">${d.id}. ${esc(d.title)}</a>`).join('')}</nav>${html}<script>async function copyTitle(id){const t=document.getElementById('title-'+id).innerText;try{await navigator.clipboard.writeText(t);document.getElementById('feedback-'+id).innerText='제목을 복사했어요.'}catch(e){selectNode('title-'+id);document.getElementById('feedback-'+id).innerText='선택된 제목을 Ctrl+C로 복사하세요.'}}function selectNode(id){const r=document.createRange();r.selectNodeContents(document.getElementById(id));const s=window.getSelection();s.removeAllRanges();s.addRange(r)}async function copyBody(id){const e=document.getElementById('body-'+id);try{await navigator.clipboard.write([new ClipboardItem({'text/html':new Blob([e.innerHTML],{type:'text/html'}),'text/plain':new Blob([e.innerText],{type:'text/plain'})})]);document.getElementById('feedback-'+id).innerText='본문과 서식을 복사했어요. 사진은 별도로 업로드하세요.'}catch(err){selectNode('body-'+id);document.getElementById('feedback-'+id).innerText='본문을 선택했어요. Ctrl+C로 복사하세요.'}}</script></body></html>`;
fs.writeFileSync(path.join(dir,'preview.html'),document);
fs.writeFileSync(path.join(dir,'drafts.txt'),'\ufeff'+text);
fs.writeFileSync(path.join(dir,'editor-guide.txt'),'\ufeff'+guide);
fs.writeFileSync(path.join(dir,'index.json'),JSON.stringify(index,null,2));
console.log(JSON.stringify({drafts:index.length,photos:photos.length,characters:index.map(d=>({id:d.id,characters:d.charactersWithoutWhitespace}))}));
