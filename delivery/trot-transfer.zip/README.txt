﻿트로트 원고 3편 집·회사 이동용 묶음

압축을 output/trot-review 폴더에 풀고 preview.html을 열면 됩니다.
preview.html: 소제목 9곳의 사진 포함 검토본
thumbnails.html: 본문과 다른 썸네일 사진 3장·후킹 문구
drafts.txt: 복사·수정 원고
photos.zip: 선택한 사진 10개·사진 출처·편집 안내
editor-guide.txt: 사진 위치·글씨·색·볼드 안내
photo-sources.json: 본인 공개 게시물·사진 맥락 기록
build.cjs: 기존 검토본을 수정할 때 쓰는 생성 자료

2026-10-07 확인한 검토본이며 네이버 저장·발행하지 않았습니다.
본인 인스타그램 공개 사진은 재사용 허락 확인본과 다릅니다.
예정 공연 날짜가 지난 경우 공식 결과·일정을 다시 확인하고 시제를 수정하세요.
최신 작성 스타일은 AGENTS.md 및 research/entertainment-blog-analysis.md의 다예 편집본 5편 기준을 먼저 읽으세요.

집에서 요청할 문구:
GitHub 최신 내용을 받아 delivery/trot-transfer.zip을 output/trot-review에 풀고 원고 3편과 편집 안내를 읽어서 연예 작업 이어서 해줘. AGENTS.md와 research/entertainment-blog-analysis.md의 최신 다예 스타일을 적용해줘. 기존 발행·임시저장과 중복하지 말고, 발행은 내가 요청할 때만 해줘.

이번 ZIP만 명시적 보관 요청으로 GitHub에 업로드합니다. 다른 원고·사진의 자동 업로드 허가는 아닙니다.